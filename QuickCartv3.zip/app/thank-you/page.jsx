const ThankYou = () => (
  <div className="min-h-screen flex items-center justify-center text-xl">
    ✅ Thank you for reaching out! We’ll get back to you shortly.
  </div>
);

export default ThankYou;
